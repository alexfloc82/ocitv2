import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-holliday',
  templateUrl: './holidays.component.html',
  styleUrls: ['./holidays.component.css']
})
export class HolidaysComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
